﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace PM03_Makoveeva
{
    class Course
    {
        public string Nazvanie = "";
        public double Kalorinost = 0;
        public double Price = 0;
    }
    static class Cafe
    {

        static public int Size;
        static public List<Course> CafeMenu = new List<Course>();
        static public void ADD()
        {
            Console.Write("Размер массива = ");
            Size = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < Size; i++)
            {
                Course TempCourse = new Course();
                Console.Write("Название блюда №" + i + " = ");
                TempCourse.Nazvanie = Console.ReadLine().ToString();

                Console.Write("Калорийность №" + i + " = ");
                TempCourse.Kalorinost = Convert.ToInt32(Console.ReadLine());

                Console.Write("Цена блюда №" + i + " = ");
                TempCourse.Price = Convert.ToDouble(Console.ReadLine());

                CafeMenu.Add(TempCourse);
            }
        }

        static public void Sort()
        {
            CafeMenu.OrderBy(r => r.Price).ThenByDescending(r => r.Kalorinost).ToArray();
        }
        static public void SaveInFile()
        {
            using (StreamWriter sw = new StreamWriter("CourseList.txt"))
            {
                foreach (Course C in CafeMenu)
                    sw.WriteLine(C.Nazvanie + ", " + C.Kalorinost + ", " + C.Price.ToString());
            }
        }

    }
    class Program
    {
       
        

        static void Main(string[] args)
        {
            Cafe.ADD();
            Cafe.Sort();
            Cafe.SaveInFile();
        }
    }
}
